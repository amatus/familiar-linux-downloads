# Version number and release date.
VERSION_NUMBER=0.14.1
RELEASE_DATE=2004-01-29      # in "date +%Y-%m-%d" format
