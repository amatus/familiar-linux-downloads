#include "../../gettext-tools/lib/readlink.c"
