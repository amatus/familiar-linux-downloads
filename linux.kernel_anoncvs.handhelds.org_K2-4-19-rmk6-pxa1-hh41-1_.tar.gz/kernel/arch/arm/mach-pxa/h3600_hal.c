#include "../mach-sa1100/h3600_hal.c"
