/*
 * contents of this file moved to dma-pxa.c to enable use of modversions.
 * - Jamey 12/16/2002
 */
