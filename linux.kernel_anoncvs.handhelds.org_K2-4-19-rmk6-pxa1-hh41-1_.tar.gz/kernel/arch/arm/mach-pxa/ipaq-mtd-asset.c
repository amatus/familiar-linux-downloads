#include "../mach-ipaq/ipaq-mtd-asset.c"
