extern int h5400_spi_init(void);

extern int h5400_asic_spi_read( unsigned short address, unsigned char *data, unsigned short len );
extern int h5400_asic_spi_write( unsigned short address, unsigned char *data, unsigned short len );

extern int h5400_asic_spi_read_pcmcia_battery( unsigned char *chem, unsigned char *percent, unsigned char *flag );

extern int h5400_asic_get_option_detect( int *result );
