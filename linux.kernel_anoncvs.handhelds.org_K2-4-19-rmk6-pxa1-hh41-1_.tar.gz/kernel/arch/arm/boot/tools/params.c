/*
 * params.c
 *
 * Copyright (c) Compaq Computer Corporation, 1998
 *
 * Author: Deborah A. Wallach.
 */

#include "./config.h"
#include "./itsy_console.h"
#include "./kdev_t.h"
#include "./major.h"
#include "./setup.h"

#define FIXMEZZZ 0
struct param_struct brutus_params = {
/*    unsigned long page_size = */        4096,
/*    unsigned long nr_pages = */         4096,
/*    unsigned long ramdisk_size = */     16384,  /* YYY want to increment this? */
/*    unsigned long mountrootrdonly = */  1,
/*    unsigned long rootdev = */          MKDEV(RAMDISK_MAJOR,0),
/*    unsigned long video_num_cols = */   I_video_num_cols,
/*    unsigned long video_num_rows = */   I_video_num_rows,
/*    unsigned long video_x = */          FIXMEZZZ,
/*    unsigned long video_y = */          FIXMEZZZ,
/*    unsigned long memc_control_reg = */ 0,
/*    unsigned char sounddefault = */     FIXMEZZZ,
/*    unsigned char adfsdrives = */       0,
/*    unsigned char bytes_per_char_h = */ I_bytes_per_char_h,
/*    unsigned char bytes_per_char_v = */ I_bytes_per_char_v,
/*    unsigned long pages_in_bank[4] = */ {0, 0, 0, 0},
/*    unsigned long pages_in_vram = */    FIXMEZZZ,
/*    unsigned long initrd_start = */     0x10000000,
/*    unsigned long initrd_size = */	  0x00700000,
/*    unsigned long version = */          0x0,
/*    ...  */
					};
