int See__usr_share_doc_fakeroot_README_fake(){
  return 0; 
}
