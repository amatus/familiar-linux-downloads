#define BIT_DIVIDER 504 
static int bits[9] = { 250,210,239,238,233,307,237,144,};
