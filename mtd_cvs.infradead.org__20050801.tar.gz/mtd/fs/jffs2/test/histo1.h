#define BIT_DIVIDER 755 
static int bits[9] = { 108,125,128,93,84,89,119,94,};
