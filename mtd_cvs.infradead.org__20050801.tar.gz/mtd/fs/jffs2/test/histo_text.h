#define BIT_DIVIDER 1187 
static int bits[9] = { 518,418,533,414,310,1069,822,1, };
