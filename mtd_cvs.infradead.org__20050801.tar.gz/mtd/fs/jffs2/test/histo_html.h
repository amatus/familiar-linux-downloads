#define BIT_DIVIDER 631 
static int bits[9] = { 268,247,324,252,199,529,436,1, };
