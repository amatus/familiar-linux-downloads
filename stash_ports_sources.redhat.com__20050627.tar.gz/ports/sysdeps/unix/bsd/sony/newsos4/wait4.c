#include <sysdeps/unix/bsd/sun/sunos4/wait4.c>
