#include <sysdeps/unix/bsd/bsd4.4/wait.c>
