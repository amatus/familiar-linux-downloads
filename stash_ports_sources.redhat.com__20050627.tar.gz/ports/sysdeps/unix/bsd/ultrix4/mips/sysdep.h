#define NO_UNDERSCORES

#include <sysdeps/unix/mips/sysdep.h>
