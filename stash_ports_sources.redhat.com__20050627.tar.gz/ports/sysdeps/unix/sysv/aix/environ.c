/* We don't need to define environ, the kernel does it.  */
