/*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*/

/*
	USAGE
	Test for blocking reads from touch screen
	WARNING - You need to calibratethe TS before you get sensible
			readings.

	The touch screen interface has it's own MINOR number.

	When the PEN touches the screen the micro controller sends
	X touch screen events per second. When the user lifts the
	PEN the touch screen events cease.
	This program calculates the average of the x and y coordinates
	between PEN DOWN and PEN UP. The coordinates are calibrated.
*/

#include <stdio.h>
#include <fcntl.h>

#include <linux/h3600_ts.h>

#define DEV_NODE "/dev/ts"
main(int argc , char ** argv)
{
	TS_EVENT event;
	int fd;
	int err;
	unsigned temp,lcount = 10;	/* kludge to exit loop */
	unsigned x,y,cnt;


	if( argc == 2 )
	{
		lcount = atoi(argv[1]);
	}
	temp=lcount;

	printf("Opening for read loop=%d...\n",temp);
	fd = open(DEV_NODE,O_RDONLY);
	if( fd < 0 )
	{
		printf("\nUnable to read from %s\n",DEV_NODE);
		exit(0);
	}

    printf("reading ...\n");
    while(temp--)
    {
	cnt=x=y=0;
	event.pressure=1;
	while(event.pressure)
	{
	    err = read(fd,(char *)&event,sizeof(TS_EVENT));
	    if( err < 0 )
	    {
			perror("pp_read:bad read");
			close(fd);
			exit(1);
	    }

	    ++cnt;
#if 0
	    printf("TS_READ:x=%d y=%d p=%d\n",event.x,event.y,event.pressure);
#endif
	    x += event.x;
	    y += event.y;
	}

	/* PEN UP now report the average */
	printf("TS_READ:x=%d y=%d\n",x/cnt,y/cnt);

    } /* end while */

	printf("\n\nEXITING LOOP COUNT (%d) EXCEEDED\n",lcount);
	close (fd);

}
