/*
 * Copyright (C) 2003 Philip Blundell <philb@gnu.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <linux/types.h>
#include <linux/ioctl.h>

#include "buzzer.h"

#define BUZZER_FILE "/dev/misc/buzzer"

void
usage (char *name)
{
  fprintf (stderr, "usage: %s on [<on time> [<off time>]]\n", name);
  fprintf (stderr, "       %s off\n", name);
  fprintf (stderr, "(times are in milliseconds.)\n");
  exit (1);
}

int
main (int argc, char *argv[])
{
  int fd;
  struct buzzer_time t;

  fd = open (BUZZER_FILE, O_WRONLY);
  if (fd < 0)
    {
      perror (BUZZER_FILE);
      exit (1);
    }

  if (argc < 2)
    usage (argv[0]);

  if (!strcmp (argv[1], "off"))
    {
      t.on_time = t.off_time = 0;
    }
  else if (!strcmp (argv[1], "on"))
    {
      t.on_time = 1000;
      t.off_time = 0;

      if (argc > 2)
	t.on_time = t.off_time = atoi (argv[2]);
      if (argc > 3)
	t.off_time = atoi (argv[3]);
    }

  if (ioctl (fd, IOC_SETBUZZER, &t))
    {
      perror ("IOC_SETBUZZER");
      exit (1);
    }

  close (fd);

  exit (0);
}
