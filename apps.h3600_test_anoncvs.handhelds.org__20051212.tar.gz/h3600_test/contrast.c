/*
  Set the screen contrast on an H3100

  Copyright (c) 2001, Compaq Computer Corporation

  Andrew Christian
  October, 2001
*/

#include <stdio.h>
#include <fcntl.h>
#include <linux/h3600_ts.h>


#define DEVICE_NAME "/dev/touchscreen/0"

void usage( void )
{
	fprintf(stderr,"Usage: contrast [LEVEL]\n");
	fprintf(stderr,"       where 0 <= LEVEL <= 255\n");
	fprintf(stderr,"       With no LEVEL, returns current contrast.\n");
	exit(0);
}

int main( int argc, char **argv )
{
	struct h3600_ts_contrast contrast;
	int fd;
	int retval = 0;

	if ( argc > 2 ) 
		usage();
	
	fd = open( DEVICE_NAME, O_RDWR );
	if ( fd < 0 ) {
		fprintf(stderr,"Unabled to open %s\n", DEVICE_NAME);
		return 1;
	}

	switch (argc) {
	case 1:
		if ( ioctl( fd, TS_GET_CONTRAST, &contrast ) < 0 ) {
			perror("Unable to read contrast");
			retval = 1;
		}
		else {
			printf("%d\n", contrast.contrast);
		}
		break;
	case 2:
		contrast.contrast = atoi(argv[1]);
//		printf("Setting contrast to %d\n", contrast.contrast );
		if ( ioctl( fd, TS_SET_CONTRAST, &contrast ) < 0 ) {
			perror("Unable to set contrast");
			retval = 1;
		}
		break;
	}

	close(fd);
	return retval;
}
