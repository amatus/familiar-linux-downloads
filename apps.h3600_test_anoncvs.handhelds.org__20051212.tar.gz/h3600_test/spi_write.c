/*
* h3600 driver example progam - SPI write
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
* WARNING!!: The ioctl() interface will change in near future versions.
*/

/*

        USAGE:

	|<-Addr_Offset->|<---- uchar data[len -2 ]------>
	+-------+-------+-------+-------+-------+-------+
	|loByte |HiByte	| 	|	|	|	|-->SPI_WRITE_CMD
	+-------+-------+-------+-------+-------+-------+

	The Atmel will respond with a NULL packet. This is interpretated
	as an ACK.
*/
#include <stdio.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#if 0
#include "h3600_ts.h"           /* IOCTL definitions */
#else
#include <linux/h3600_ts.h>
#endif



#define DEV_NODE "/dev/h3600_ts"

main(int argc, char ** argv )
{
	SPI_WRITE iw;
	int fd;
	int err;
	int count;
	unsigned i;
	unsigned char * ptr;
	unsigned int start_val=0;

	for(i=0; i < (SPI_WR_BUFSIZ) ; i++)
	 iw.buff[i]=0;

        switch(argc)
        {
        case 1:
                /* take defaults */
                iw.addr = 0;
                iw.len=1;
                iw.buff[0] = 0x01;
        case 2:
                iw.addr = (unsigned char)atoi(argv[1]);
                iw.len=SPI_WR_BUFSIZ;
                for(i=0; i < SPI_WR_BUFSIZ; i++)
                    iw.buff[i] = i;
                break;
        case 3:
                iw.addr = (unsigned char)atoi(argv[1]);
                iw.len = (unsigned short)atoi(argv[2]);
                for(i=0; i < iw.len; i++)
                    iw.buff[i] = i;
                break;
	case 4: 
                iw.addr = (unsigned char)atoi(argv[1]);
                iw.len = (unsigned short)atoi(argv[2]);
                start_val = (unsigned int)atoi(argv[3]);
		printf("start_val=%d\n",start_val);
                for(i=0; i <  iw.len  ; i++)
                    iw.buff[i] = start_val + i;
                break;
        default:
            printf("usage: spi_wr [address 0-256] [len=1,%d]\n",SPI_WR_BUFSIZ);
            exit(1);
        }
		
#if 0
	printf("addr=%04x val=%02x\n",iw.addr,iw.buff[0]);
#endif
	if (iw.len > SPI_WR_BUFSIZ )
	{
		/* TODO check why we can only write this amount of data
			at any one time.
		*/
		printf("Adjusting len from %d to %d\n",
			iw.len,SPI_WR_BUFSIZ);
		iw.len=SPI_WR_BUFSIZ;
	}
	fd = open(DEV_NODE,O_RDWR);
	if( fd == -1 )
	{
		printf("\nUnable to open %s\n",DEV_NODE);
		exit(0);
	}

        err = ioctl(fd,WRITE_SPI,(void *)&iw);
        if( err < 0 )
        {
                perror("A:bad ioctl");
                close(fd);
                exit(1);
        }

	close (fd);
	printf("done ...\n");
}
