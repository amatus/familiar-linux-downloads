/*
*
* h3600 driver example program - button management
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
*/

/*
	Program which reads the h3600 buttons
	The driver returns a single byte formatted as follows:
	bit 7 = state bits0-3 = key number
	Example: 0x87= button 7 is is down.
	Example: 0x07= button 7 is up.

	The microcontroller will debounce the buttons such that
	only two events (UP and DOWN) should be expected for
	each activation.
	
	This interface has it's own MINOR number (see h3600_ts.c/h)
*/

#include <stdio.h>
#include <fcntl.h>


/* TODO move to header file */
#define KEY_OFF 0x80
#define KEY_NUM 0x0f

#define DEV_NODE "/dev/h3600_key"
main(int argc , char ** argv)
{
    unsigned char key;
    int fd;
    int err;
    unsigned temp,lcount = 5;	/* kludge to exit loop */
    unsigned char * state;

    if( argc == 2 )
    {
		lcount = atoi(argv[1]);
    }
    temp=lcount;

    printf("Opening for read loop=%d...\n",temp);
    fd = open(DEV_NODE,O_RDONLY);
    if( fd < 0 )
    {
		printf("\nUnable to read from %s\n",DEV_NODE);
		exit(0);
    }

    printf("reading buttons...\n");
    while(temp--)
    {
	err = read(fd,(char *)&key,1);
	if( err < 0 )
	{
			perror("pp_read:bad read");
			close(fd);
			exit(1);
	}
	state = ( key & KEY_OFF ) ? "OFF" : "ON";
	printf("USER[%02x]KEY %d is %s\n", key, key & KEY_NUM, state );

    } /* end while */

    printf("\n\nEXITING LOOP COUNT (%d) EXCEEDED\n",lcount);
    close (fd);

}
