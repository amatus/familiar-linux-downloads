/*
*
* h3600 driver example program - battery status reader
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Jamey Hicks (adapted from key_read.c)
* Author: Charles Flynn.
*
*/

/*
	Program which reads the h3600 battery status
        See include/linux/h3600_ts.h for flags and status bit definitions.
	
*/

#include <stdio.h>
#include <fcntl.h>
#include <linux/h3600_ts.h>

#define DEV_NODE "/dev/touchscreen/0"

int main(int argc , char ** argv)
{
        int fd;
        int err;
        struct h3600_battery batt_info;
	int i;

        memset(&batt_info, 0, sizeof(batt_info));

        fd = open(DEV_NODE,O_RDONLY);
        if( fd < 0 )
        {
		printf("\nUnable to read from %s\n",DEV_NODE);
		exit(1);
        }

        printf("reading battery status...\n");
        err=ioctl(fd, GET_BATTERY_STATUS, &batt_info);
	if ( err < 0 ) {
		perror("Unable to read battery status\n");
		close(fd);
		exit(1);
	}

        printf("ac_status=%x number_of_battyers=%d\n", batt_info.ac_status, batt_info.battery_count);
	for ( i = 0 ; i < batt_info.battery_count ; i++ ) 
		printf("Battery #%d:  batt_chem=%x  batt_voltage=%x batt_status=%d\n",
		       batt_info.battery[i].chemistry, batt_info.battery[i].voltage, batt_info.battery[i].status);
        close (fd);
	return 0;
}
