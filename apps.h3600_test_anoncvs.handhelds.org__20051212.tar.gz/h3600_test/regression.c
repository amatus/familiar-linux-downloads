/*
*
* h3600 driver example progam - generic get 
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
*/
                                                                
#include <stdio.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#if 0
#include "h3600_ts.h"           /* IOCTL definitions */
#else
#include <linux/h3600_ts.h>
#endif

#define DEV_NODE "/dev/h3600_ts"

#define INTER_TEST_DELAY 	2	/* seconds */
#define FLITE_FADE_MS		7	/* m/s */

#define EXIT_ON_ERROR(msg)      \
        if( err  )         	\
        {                       \
                perror(msg);                            \
                if(fd)                                  \
                        close(fd);                      \
                exit(1);                                \
        }


void disp(FLITE_IN * fin)
{
	printf("Mode=%02x\n Pwr=%02x\n Bright=%02x\n",
		fin->mode,fin->pwr,fin->brightness);
}
main(int argc, char ** argv )
{
	FLITE_IN bl_off={1,0,0};	/* light off */
	FLITE_IN bl_on={1,1,255};	/* light full on */
	LED_IN led_off={0,0,0,0};	/* led off */
	LED_IN led_on={1,1,1,1};	/* led on */
	VER_RET	ver;			/* returns maj and minor */
	int fd,err,i;

	fd = open(DEV_NODE,O_RDWR);
	if( fd == -1 )
	{
		printf("\nUnable to open %s\n",DEV_NODE);
		exit(0);
	}

	printf("(1)FRONT LIGHT OFF:\n");
        err = ioctl(fd,FLITE_ON,(void *)&bl_off);
	EXIT_ON_ERROR("FLITE_OFF:bad ioctl");

	sleep(2);
	printf("(2)FRONT LIGHT FADE ON:\n");
	for(i=0; i < 256; i++ )
	{
		bl_on.brightness=i;
		if(0) disp(&bl_on);
        	err = ioctl(fd,FLITE_ON,(void *)&bl_on);
		EXIT_ON_ERROR("FLITE_FADE_ON:bad ioctl");
		usleep(FLITE_FADE_MS * 1000);
	}

	sleep(INTER_TEST_DELAY);
	printf("(3)LED FLASHING:\n");
        err = ioctl(fd,LED_ON,(void *)&led_on);
	EXIT_ON_ERROR("LED FLASHING:bad ioctl");

	sleep(INTER_TEST_DELAY);
	printf("(4)GET VERSION NUMBER\n");
        err = ioctl(fd,GET_VERSION,(void *)&ver);
	EXIT_ON_ERROR("GET VERSION:bad ioctl");
	printf("Version number = %s\n",ver.host_version);
	if( ver.pack_version[0] )
	{
	    printf("Option pack version number = %s\n",ver.pack_version);
	    printf("Boot Type = %02x\n",ver.boot_type);
	}

	sleep(INTER_TEST_DELAY);
	printf("(5)LED OFF:\n");
        err = ioctl(fd,LED_ON,(void *)&led_off);
	EXIT_ON_ERROR("LED OFF:bad ioctl");

	sleep(INTER_TEST_DELAY);
	printf("(6)FRONT LIGHT FADE OFF:\n");
	for(i=255; i > 0; i--)
	{
		bl_on.brightness=i;
		if(0) disp(&bl_on);
        	err = ioctl(fd,FLITE_ON,(void *)&bl_on);
		EXIT_ON_ERROR("FLITE FADE OFF:bad ioctl");
		usleep(FLITE_FADE_MS * 1000);
	}

	close (fd);
}
