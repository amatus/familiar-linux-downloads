/*
*
* h3600 driver example program - raw touch screen interface
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
*/

/*
	USAGE for tsraw.c
	This interface has it's own MINOR number.
	It reads uncalibrated touch screen data.
	It is used by the touch screen calibration application
		or for simply test purposes.
	It reports the raw X,Y coords each time the user touches the
		screen. When the pen is lifted a new set of raw coordinates
		is reported.
        A single command line arg determines how many events are reported
                before it exits.
*/
#include <stdio.h>
#include <fcntl.h>

#include <linux/h3600_ts.h>

#define DEV_NODE "/dev/tsraw"
main(int argc , char ** argv)
{
	TS_EVENT event;
	int fd;
	int err;
	unsigned temp,lcount = 10;	/* kludge to exit loop */
	unsigned x,y,cnt;


	if( argc == 2 )
	{
		lcount = atoi(argv[1]);
	}
	temp=lcount;

	printf("Opening for read loop=%d...\n",temp);
	fd = open(DEV_NODE,O_RDONLY);
	if( fd < 0 )
	{
		printf("\nUnable to read from %s\n",DEV_NODE);
		exit(0);
	}

    printf("reading ...\n");
    while(temp--)
    {
	cnt=x=y=0;
	event.pressure=1;
	while(event.pressure)
	{
	    err = read(fd,(char *)&event,sizeof(TS_EVENT));
	    if( err < 0 )
	    {
			perror("bad read");
			close(fd);
			exit(1);
	    }

	    ++cnt;
#if 0
	    printf("TS_RAW:x=%d y=%d\n",event.x,event.y);
#endif
	    x += event.x;
	    y += event.y;
	}

	/* PEN UP now report the average */
	printf("TS_RAW:x=%d y=%d\n",x/cnt,y/cnt);

    } /* end while */

	printf("\n\nEXITING LOOP COUNT (%d) EXCEEDED\n",lcount);
	close (fd);

}
