/*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Jamey Hicks.

*/


/*
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include <linux/h3600_ts.h>

/* NOTE led works with any minor number */
#define DEV_NODE "/dev/ts"

main(int argc, char ** argv )
{
	EEPROM_REQ req;
	int fd;
	int err;
	int count;
        int i;
		
	fd = open(DEV_NODE,O_RDWR);
	if( fd == -1 )
	{
		printf("%s: Unable to open %s\n", argv[0], DEV_NODE);
		exit(0);
	}

        req.addr = 0;
        if (argv[1] != NULL) {
          req.addr = atoi(argv[1]);
        }
        req.len = 8;
        if (argv[2] != NULL) {
          req.len = atoi(argv[2]);
        }
	err = ioctl(fd,READ_EEPROM,(void *)&req);
	if ( err < 0 ) {
		perror("eeprom_read: ioctl");
		close(fd);
		exit(1);
	}

        printf("addr=%#02x len=%02x data=", req.addr, req.len);
        for (i = i; i < req.len; i++)
           printf(" %02x", req.buf[i]);
        printf("\n");

	close (fd);
	printf("done\n");
}
