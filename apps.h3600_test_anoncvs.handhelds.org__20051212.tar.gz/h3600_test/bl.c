/*
*
* h3600 driver example progam - backlight control
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
* 
* Updated by Andrew Christian
*            October, 2001
*/
                                                                
/*
	USAGE for bl.c
	There are 3 parameters
	mode = AUTO=1 MENU=2
	pwr = 1 (power on) 0 = power off
	brightness 0-255 (0 means off) 

	Example
	mknod h3600_ts c 254 0
	( cat/proc/devices to get major number and ensure minor is 13 )
	./bl_write 1 1 80	- turn back light on - brightness = 80
	./bl_write 1 0 x	- turn back light off (x = dont care )

	This interface can be called from any of the device MINOR numbers.
*/

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include <linux/h3600_ts.h>

/* The ioctl can be called from a ts, tsraw or key file descriptor */
#define DEV_NODE "/dev/touchscreen/0"
int debug = 0;

void usage( void )
{
	fprintf(stderr,"Usage: bl MODE POWER BRIGHTNESS   Set using full triple [deprecated]\n");
	fprintf(stderr,"       bl                         Returns current frontlight/backlight\n");
	fprintf(stderr,"       bl VALUE                   Turns on and sets to VALUE (0 - 255)\n");
	fprintf(stderr,"       bl off                     Turns off frontlight/backlight\n");
	fprintf(stderr,"       bl on                      Turns on frontlight/backlight to last setting\n");
	fprintf(stderr,"Options:\n");
	fprintf(stderr,"       --help,-h                  Returns this message\n");
	fprintf(stderr,"\nPlease note: H3100 iPAQs have a screen backlight that can be either on or off (no level).\n");
	fprintf(stderr,"             H3600 and higher iPAQs have a screen frontlight that can be set from 0 to 255\n");
	fprintf(stderr,"             or turned off.\n");

	exit(0);
}

int set_backlight( int fd, struct h3600_ts_backlight *bl )
{
	if ( ioctl( fd, TS_SET_BACKLIGHT, bl ) < 0 ) {
		perror("Unable to write backlight");
		return 1;
	}
	return 0;
}

int main(int argc, char ** argv )
{
	struct h3600_ts_backlight bl;
	struct h3600_ts_flite     fl;
	int fd;
	int retval;

	fd = open(DEV_NODE,O_RDWR);
	if( fd < 0 ) {
		fprintf(stderr,"\nUnable to open %s\n",DEV_NODE);
		exit(1);
	}

	if ( ioctl( fd, TS_GET_BACKLIGHT, &bl ) < 0 ) {
		perror("Unable to read backlight");
		close(fd);
		return 1;
	}

	if ( argc > 1 && argv[1][0] == '-' )
		usage();

	switch (argc) {
	case 1:   /* No arguments */
		printf("%s %d\n", (bl.power == FLITE_PWR_OFF ? "off" : "on"), bl.brightness );
		break;
	case 2:   /* One argument */
		if ( !strcasecmp(argv[1],"off") ) {
			if (debug) printf("Turning off\n");
			bl.power = FLITE_PWR_OFF;   /* Don't adjust the current brightness */
		}
		else if ( !strcasecmp(argv[1],"on")) {
			if (debug) printf("Turning on\n");
			bl.power = FLITE_PWR_ON;
		}
		else if ( !strcasecmp(argv[1], "toggle")) {
			bl.power = (bl.power == FLITE_PWR_OFF) ? FLITE_PWR_ON : FLITE_PWR_OFF;
			if (debug) printf("Turning %s\n", (bl.power == FLITE_PWR_OFF) ? "off" : "on");
		}
		else {
			bl.power = FLITE_PWR_ON;
			bl.brightness = atoi(argv[1]);
			if (debug) printf("Turning to %d\n", bl.brightness);
		}
		retval = set_backlight( fd, &bl );
		break;
	case 4:   /* Three arguments */
		fl.mode       = (unsigned char)atoi(argv[1]);
		fl.pwr        = (unsigned char)atoi(argv[2]);
		fl.brightness = (unsigned char)atoi(argv[3]);
		if ( ioctl( fd, FLITE_ON, &fl ) < 0 ) {
			perror("Unable to set frontlight\n");
			retval = 1;
		}
		break;
	default:
		usage();
		break;
	}

	close (fd);
	return 0;
}
