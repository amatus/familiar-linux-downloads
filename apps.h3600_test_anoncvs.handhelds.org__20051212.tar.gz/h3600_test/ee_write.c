/*
* h3600 driver example progam - EEPROM write
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
* WARNING!!: The ioctl() interface will change in near future versions.
*/

/*

        USAGE:

        	|<------ short data[2]--------->|
        +-------+-------+-------+-------+-------+
        |Offset	|lo     |Hi     |lo     |Hi     |-->EEPROM_WRITE_CMD
        +-------+-------+-------+-------+-------+ (byte stream sent to Atmel)

	unsigned char offset;
	short data[6];

	The EEPROM consists of 128, 16bit words, with an address range
	of (0-128).

	Examples:
	offset=1, data[0]=0x1234 will result in the value 0x1234 being written
	at offset=1.
	offset=3, data[0]=0x1234,data[1]=0x4321 will result in the values
	 0x1234 and 0x4321 being written starting at offset=3.

	The Atmel will respond with a NULL packet. This is interpretated
	as an ACK.
*/
#include <stdio.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#if 0
#include "h3600_ts.h"           /* IOCTL definitions */
#else
#include <linux/h3600_ts.h>
#endif



#define DEV_NODE "/dev/h3600_ts"

main(int argc, char ** argv )
{
	EEPROM_WRITE ew;
	int fd;
	int err;
	int count;
	unsigned int i;
	unsigned short start_val;

	switch(argc)
	{
	case 1:
		/* take defaults */
		ew.addr = 0;
		ew.len=1;
		ew.buff[0] = 0x0102;
	case 2:
		ew.addr = (unsigned char)atoi(argv[1]);
		ew.len=EEPROM_WR_BUFSIZ;
		for(i=0; i < EEPROM_WR_BUFSIZ; i++)
		    ew.buff[i] = i;
		break;
	case 3:
		ew.addr = (unsigned char)atoi(argv[1]);
		ew.len = (unsigned short)atoi(argv[2]);
		if( ew.len > EEPROM_WR_BUFSIZ)
		    ew.len = EEPROM_WR_BUFSIZ;
		for(i=0; i < ew.len; i++)
		    ew.buff[i] = i;
		break;
	case 4: 
                ew.addr = (unsigned char)atoi(argv[1]);
                ew.len = (unsigned short)atoi(argv[2]);
		if( ew.len > EEPROM_WR_BUFSIZ)
		    ew.len = EEPROM_WR_BUFSIZ;
                start_val = (unsigned short)atoi(argv[3]);
		printf("start_val=%d\n",start_val);
                for(i=0; i <  ew.len  ; i++)
                    ew.buff[i] = (unsigned short)(start_val + i);
                break;

	default:
		printf("usage: ee_write [address 0-128<0>)] [len<%d> ]\n",
			EEPROM_WR_BUFSIZ);
		exit(1);
	}
		
#if 0
	printf("Writing %d bytes starting at addr=%d and value %d\n",
		ew.len,ew.addr,ew.buff[0]);
#endif

	fd = open(DEV_NODE,O_RDWR);
	if( fd == -1 )
	{
		printf("\nUnable to open %s\n",DEV_NODE);
		exit(0);
	}

        err = ioctl(fd,WRITE_EEPROM,(void *)&ew);
        if( err < 0 )
        {
                perror("A:bad ioctl");
                close(fd);
                exit(1);
        }

	close (fd);
	printf("done ...\n");
	/* printf("bytes successfully transmitted\n"); */
}
