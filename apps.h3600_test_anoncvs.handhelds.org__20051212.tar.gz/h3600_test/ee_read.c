/*
*
* h3600 driver example progam - EEPROM read
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
* WARNING!!: The ioctl() interface will change in near future versions.
*/
                                                                
/*

	USAGE:

	+-------+-------+
	|Offset	| Len	|---->EEPROM_READ_CMD (byte_stream sent to Atmel)
	+-------+-------+

	|<------ short data[2]--------->|
	+-------+-------+-------+-------+
	|lo 	|Hi	|lo	|Hi	|<--EEPROM_READ_RES
	+-------+-------+-------+-------+ (byte stream read from Atmel Len=2)

	There are 2 parameters
	unsigned char offset (0-128)
	unsigned char length  (2-6)

	Seems like you can only read 6 words at a single go.
	
        The EEPROM consists of 128, 16bit words, with an address range
        of (0-128).

	Example
	0,1 will read 1 16bit word starting at offset 0.
	2-bytes will be returned 
	5,3 will read 3 16bit words starting at offset 5.
	6-bytes will be returned 

	This interface can be called from any of the device MINOR numbers.
*/

#include <stdio.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#if 0
#include "h3600_ts.h"           /* IOCTL definitions */
#else
#include <linux/h3600_ts.h>
#endif

/* The ioctl can be called from a ts, tsraw or key file descriptor */
#define DEV_NODE "/dev/h3600_ts"
#define MAX_LEN 6	/* TODO this returns 12 bytes any more doesnt work */

main(int argc, char ** argv )
{
	EEPROM_READ er;
	int fd;
	int err;
	int count;
	unsigned char addr;

        switch(argc)
        {
            case 1:
		/* take defaults */
                er.addr = 0;
                er.len = MAX_LEN;
                break;
            case 2:
                /* take default=12 for len*/
                er.addr = (unsigned char)atoi(argv[1]);
                er.len = MAX_LEN;
                break;
            case 3:
                er.addr = (unsigned char)atoi(argv[1]);
                er.len = (unsigned char)atoi(argv[2]);
                break;
            default:
                printf("\nusage: ee_read <address=0-128> <length=1-6>\n");
                exit(1);
                break;
	}

#if 0
	printf("\nA:Reading %d 16-bit words from offset %d\n",er.len,er.addr);
#endif
	addr = er.addr;
	fd = open(DEV_NODE,O_RDWR);
	if( fd == -1 )
	{
		printf("\nUnable to open %s\n",DEV_NODE);
		exit(0);
	}

        err = ioctl(fd,READ_EEPROM,(void *)&er);
        if( err < 0 )
        {
                perror("A:bad ioctl");
                close(fd);
                exit(1);
        }


	close (fd);

	{
	unsigned i;
	printf("\nA:AddrOffset=%d Len=%d\n",er.len,er.addr);
	printf("A:buff:");
	for( i =0; i < er.len ; i++)
		printf("%02x:",er.buff[i]);
	printf(" [%d(decimal)]\n",(unsigned)(addr + er.len) );
	}
}
