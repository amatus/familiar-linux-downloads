/*
* Copyright 2000,2001 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
* Modified by : Andrew Christian
*               October, 2001
*/


/*
	USAGE for led.c

	There are 4 parameters
	OffOn	 - Off=0 On=1
	TotalTime - increments of 1 minute that led stays on.
	OnTime	- how long in 100m/s will led pulse on.
	OffTime - how long in 100m/s will led pulse off.

	Example
	./led_write 1 2 10 5
	Will turn the led on for 1 second and off for 500m/s.
	This pulsing will last for 2 minutes.

	./led_write 0 0 0 0
	Will turn led off

	You should also get an Ack from the Atmel.

	This interface can be called from any of the device MINOR numbers.
*/

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include <linux/h3600_ts.h>

/* NOTE led works with any minor number */
#define DEV_NODE "/dev/touchscreen/0"

void usage( void )
{
	fprintf(stderr,"Usage: led TYPE TIME ONTIME OFFTIME  Set using full quad [deprecated]\n");
	fprintf(stderr,"       led off                       Turns off LED\n");
	fprintf(stderr,"       led on                        Turns on LED\n");
	fprintf(stderr,"       led blink [ONTIME] [OFFTIME] [DURATION] Blinks for TIME seconds\n" );
	fprintf(stderr,"\nNotes: DURATION is meassured in units of minutes.  If you leave DURATION out, it\n");
	fprintf(stderr,"       blinks forever.  ONTIME and OFFTIME are in units of 100 millseconds\n"); 
	exit(0);
}


int main(int argc, char ** argv )
{
	struct h3600_ts_led led;
	int fd;
	int err;
	int count;

	if ( argc == 0 || (argc > 1 && argv[1][0] == '-') )
		usage();

	led.TotalTime = 0;
	led.OnTime = 1;
	led.OffTime = 1;
	led.OffOnBlink = 1;

	if ( argc <= 1 )
		usage();

	if ( !strcasecmp("off", argv[1]) && argc == 2) {
		led.OffOnBlink = 0;
		led.OnTime = 0;
	} else if ( !strcasecmp("on", argv[1]) && argc == 2) {
		led.OffOnBlink = 1;
		led.OnTime = 0;
	} else if ( !strcasecmp("blink", argv[1]) && argc >= 2 && argc <= 5) {
		if ( argc == 5 ) {
			led.TotalTime = atoi(argv[4]);
		}
		if ( argc >= 4 ) {
			led.OffTime = atoi(argv[3]);
		}
		if ( argc >= 3 ) {
			led.OnTime = atoi(argv[2]);
		}
	} else if ( argv[1][0] == '-' || argc != 5 ) {
		usage();
	} else {
		led.OffOnBlink = (unsigned char)atoi(argv[1]);
		led.TotalTime = (unsigned char)atoi(argv[2]);
		led.OnTime = (unsigned char)atoi(argv[3]);
		led.OffTime = (unsigned char)atoi(argv[4]);
	}
		
	fd = open(DEV_NODE,O_RDWR);
	if( fd == -1 ) {
		printf("\nUnable to open %s\n",DEV_NODE);
		return 1;
	}

	err = ioctl(fd,LED_ON,(void *)&led);
	if( err < 0 ) {
		perror("led:bad ioctl");
		close(fd);
		return 1;
	}

	close (fd);
	return 0;
}
