/*
*
* h3600 driver example progam - SPI read
*
* Copyright 2000 Compaq Computer Corporation.
*
* Use consistent with the GNU GPL is permitted,
* provided that this copyright notice is
* preserved in its entirety in all copies and derived works.
*
* COMPAQ COMPUTER CORPORATION MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
* AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
* FITNESS FOR ANY PARTICULAR PURPOSE.
*
* Author: Charles Flynn.
*
* WARNING!!: The ioctl() interface will change in near future versions.
*/
                                                                
/*

	USAGE:

	|<-Addr_Offset->|
	+-------+-------+-------+
	|loByte |HiByte	| len	|---->SPI_READ_CMD
	+-------+-------+-------+

	IICRdRes - called by the event handler in response to a epromRdCmd.
	|<----- uchar data[len]-------->|
	+-------+-------+-------+-------+
	| 	|	|	|	|<--SPI_READ_RES
	+-------+-------+-------+-------+
	Note: 0 <= len <= 16


	There are 2 parameters passed in the buffer to the ioctl()
	unsigned short offset (0-128)
	unsigned char length  (2-6)
	
	This interface can be called from any of the device MINOR numbers.
*/

#include <stdio.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#if 0
#include "h3600_ts.h"           /* IOCTL definitions */
#else
#include <linux/h3600_ts.h>
#endif


/* The ioctl can be called from a ts, tsraw or key file descriptor */
#define DEV_NODE "/dev/h3600_ts"

main(int argc, char ** argv )
{
	SPI_READ ir;
	int fd;
	int err;
	int count;
	unsigned short addr;

	/*
	TODO TODO
	If sizeof(address) = 16 then we can specify 64K addresses
	but the WINCE code specifies only 256
	*/
	switch(argc)
	{
	    case 1:
		/* take defaults */
                ir.addr = 0;
                ir.len = 1;
		break;
	    case 2:
		/* take default=14 for len*/
                ir.addr = (unsigned short)atoi(argv[1]);
                ir.len = 14;
		
		break;
	    case 3:
                ir.addr = (unsigned short)atoi(argv[1]);
                ir.len = (unsigned char)atoi(argv[2]);
		break;
	    default:
		printf("\nusage: iic_read <address=0-255> <length=1-14>\n");
		exit(1);
		break;
	}
		
#if 0
	printf("\nA:Reading %d 16-bit words from offset %d\n",ir.len,ir.addr);
#endif
	/* TODO Lengths greater than 14 seem to give bad frames */
	if( ir.len > 14 )
	    ir.len=14;

	addr=ir.addr;	/* TODO save it cos it's not returned from driver */
	fd = open(DEV_NODE,O_RDWR);
	if( fd == -1 )
	{
		printf("\nUnable to open %s\n",DEV_NODE);
		exit(0);
	}

        err = ioctl(fd,READ_SPI,(void *)&ir);
        if( err < 0 )
        {
                perror("A:bad ioctl");
                close(fd);
                exit(1);
        }

	close (fd);

	{
	unsigned i;
#if 0
	printf("\nA:AddrOffset=%d Len=%d\n",ir.addr,ir.len);
#endif
	printf("A:buff:");
	for( i =0; i < ir.len ; i++)
		printf("%02x:",ir.buff[i]);
	printf(" [%d(decimal)]\n",addr+ir.len);
	}
}
